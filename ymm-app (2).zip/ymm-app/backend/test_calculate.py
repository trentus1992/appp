import requests

# Define the endpoint URL
url = "http://127.0.0.1:5000/calculate"

# Define the data to send with the request
data = {
    'age': 30,
    'gender': 'male',
    'weight': 70,
    'height': 175
}

# Send a POST request
response = requests.post(url, data=data)

# Print the response
print("Raw Response:", response.text)
print("Parsed as JSON:", response.json())
